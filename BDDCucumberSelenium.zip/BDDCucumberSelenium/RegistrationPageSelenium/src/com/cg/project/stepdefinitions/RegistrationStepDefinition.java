package com.cg.project.stepdefinitions;

import org.openqa.selenium.WebDriver;

import com.cg.project.pagebeans.RegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition
{
	private WebDriver driver;
	private RegistrationPageBean register;
	@Given("^User is on the registration page$")
	public void user_is_on_the_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit without entering 'UserId'$")
	public void user_is_trying_to_submit_without_entering_UserId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'UserId should not be empty/length be between (\\d+)-(\\d+)' alert message should display$")
	public void userid_should_not_be_empty_length_be_between_alert_message_should_display(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit without entering 'Password'$")
	public void user_is_trying_to_submit_without_entering_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Password should not be empty/length be between (\\d+)-(\\d+)' alert message should display$")
	public void password_should_not_be_empty_length_be_between_alert_message_should_display(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit without entering 'name'$")
	public void user_is_trying_to_submit_without_entering_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'name should not be empty and must have alphabet characters omly' alert message should display$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_omly_alert_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
